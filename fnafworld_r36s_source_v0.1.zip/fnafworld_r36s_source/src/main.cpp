#include <SDL2/SDL.h>
#include <algorithm>
#include <array>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

// Original-from-scratch 2D RPG foundation for Linux handhelds.
// Uses geometric placeholder art; no proprietary game assets are included.
namespace {
constexpr int W = 640, H = 360;
enum class Scene { Title, World, Battle, Party, Options };
struct Hero { const char* name; int hp, maxHp, power; SDL_Color color; };
std::array<Hero,4> party{{
 {"Freddy", 36,36,8,{235,174,66,255}},
 {"Bonnie", 30,30,10,{116,116,245,255}},
 {"Chica", 34,34,7,{255,224,80,255}},
 {"Foxy", 28,28,12,{230,91,69,255}}
}};
struct Enemy { std::string name="Glitch Bug"; int hp=42, maxHp=42, power=5; } enemy;
SDL_Window* window=nullptr; SDL_Renderer* renderer=nullptr;
Scene scene=Scene::Title;
int px=320, py=190, selected=0, worldX=0, worldY=0, encounterSteps=0, messageTicks=0;
int level=1, coins=0, option=0;
std::string message="Press A / Enter to start";
bool running=true;

void rect(int x,int y,int w,int h, SDL_Color c) { SDL_SetRenderDrawColor(renderer,c.r,c.g,c.b,c.a); SDL_Rect r{x,y,w,h}; SDL_RenderFillRect(renderer,&r); }
void line(int x1,int y1,int x2,int y2, SDL_Color c) { SDL_SetRenderDrawColor(renderer,c.r,c.g,c.b,c.a); SDL_RenderDrawLine(renderer,x1,y1,x2,y2); }
// Tiny readable bitmap font, enough for menus without external assets.
const unsigned char* glyph(char c) {
 static const unsigned char blank[7]={0,0,0,0,0,0,0};
 static const unsigned char letters[36][7]={
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31},
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14}};
 c=(char)SDL_toupper((unsigned char)c);
 if(c>='A'&&c<='Z') return letters[c-'A']; if(c>='0'&&c<='9') return letters[26+c-'0']; return blank;
}
void text(int x,int y,const std::string& s, SDL_Color c={240,244,255,255},int scale=2) {
 int ox=x; for(char ch:s){ if(ch=='\n'){y+=9*scale;x=ox;continue;} if(ch==' '){x+=4*scale;continue;} auto g=glyph(ch); for(int row=0;row<7;row++) for(int col=0;col<5;col++) if(g[row]&(1<<(4-col))) rect(x+col*scale,y+row*scale,scale,scale,c); x+=6*scale; }
}
void panel(int x,int y,int w,int h){rect(x,y,w,h,{12,18,37,240});rect(x,y,w,2,{100,219,209,255});rect(x,y+h-2,w,2,{100,219,209,255});rect(x,y,2,h,{100,219,209,255});rect(x+w-2,y,2,h,{100,219,209,255});}
void saveGame(){ std::ofstream f("fnafworld_rpg_save.dat"); if(!f)return; f<<px<<' '<<py<<' '<<level<<' '<<coins<<' '<<worldX<<' '<<worldY<<'\n'; for(auto& h:party) f<<h.hp<<' '; }
void loadGame(){ std::ifstream f("fnafworld_rpg_save.dat"); if(!f)return; f>>px>>py>>level>>coins>>worldX>>worldY; for(auto& h:party) f>>h.hp; }
void startBattle(){ scene=Scene::Battle; enemy={"Glitch Bug",30+level*12,30+level*12,4+level}; selected=0; message="A WILD GLITCH BUG APPEARED!"; messageTicks=100; }
void attack(){ int alive=0; for(auto& h:party)if(h.hp>0)alive++; if(!alive){message="PARTY DOWN! PRESS B TO RETRY";messageTicks=999;return;} Hero& h=party[selected]; if(h.hp<=0){message="THAT HERO NEEDS A REVIVE!";messageTicks=80;return;} enemy.hp-=h.power+level; if(enemy.hp<=0){enemy.hp=0; coins+=8+level*2; level=std::min(99,level+1); message="VICTORY! PARTY GAINED EXP!"; messageTicks=100; return;} int target=(selected+1)%4; for(int i=0;i<4;i++){int idx=(target+i)%4;if(party[idx].hp>0){party[idx].hp=std::max(0,party[idx].hp-enemy.power);break;}} message="YOUR TEAM ATTACKED!";messageTicks=55; }
void drawHero(int x,int y,SDL_Color c){rect(x-8,y-13,16,18,c);rect(x-7,y-22,14,10,c);rect(x-5,y-19,3,3,{255,255,255,255});rect(x+2,y-19,3,3,{255,255,255,255});rect(x-5,y+5,4,7,{35,39,57,255});rect(x+2,y+5,4,7,{35,39,57,255});}
void render(){ SDL_SetRenderDrawColor(renderer,8,12,27,255); SDL_RenderClear(renderer);
 if(scene==Scene::Title){ text(105,54,"FNAF WORLD",{100,219,209,255},5);text(147,112,"R36S RPG PROJECT",{235,174,66,255},2);panel(160,190,320,90);text(190,210,"A / ENTER  START",{255,255,255,255},2);text(185,239,"B / ESC  QUIT",{190,200,225,255},2);text(145,320,"ORIGINAL CODE PROTOTYPE - V0.1",{130,148,180,255},1); }
 else if(scene==Scene::World){ // tile-map test area
  for(int y=36;y<H-45;y+=24) for(int x=0;x<W;x+=24){ bool grass=((x/24+y/24)%2)==0;rect(x,y,23,23,grass?SDL_Color{35,91,72,255}:SDL_Color{30,80,65,255}); }
  for(int x=0;x<W;x+=24) rect(x,265,23,23,{100,84,53,255});
  for(int i=0;i<7;i++){rect(65+i*78,70+(i%2)*25,24,35,{20,50,44,255});rect(60+i*78,61+(i%2)*25,34,18,{28,46,54,255});}
  rect(420,120,65,75,{90,67,105,255});rect(414,114,77,8,{100,219,209,255});
  drawHero(px,py,{235,174,66,255}); panel(8,6,210,25);text(17,13,"LV "+std::to_string(level)+"   COINS "+std::to_string(coins),{255,255,255,255},1);
  panel(8,300,624,50);text(18,309,"D-PAD MOVE   A INTERACT   X PARTY   Y MENU",{255,255,255,255},1);text(18,328,"WALK TO EXPLORE - FIND THE GLITCHES",{100,219,209,255},1);
 }
 else if(scene==Scene::Battle){ panel(20,18,600,190);text(40,30,"RANDOM ENCOUNTER",{100,219,209,255},2);rect(80,80,120,60,{82,48,111,255});rect(95,62,90,26,{108,72,139,255});rect(103,69,15,9,{255,255,255,255});rect(155,69,15,9,{255,255,255,255});text(260,70,enemy.name,{255,255,255,255},2);rect(260,100,270,12,{50,55,70,255});rect(260,100,270*enemy.hp/enemy.maxHp,12,{230,91,69,255});text(260,123,"HP "+std::to_string(enemy.hp)+" / "+std::to_string(enemy.maxHp),{255,255,255,255},1);
  panel(20,220,600,125); for(int i=0;i<4;i++){int x=35+(i%2)*292,y=232+(i/2)*48; if(i==selected)rect(x-6,y-5,280,40,{42,64,83,255});text(x,y,party[i].name,{party[i].color.r,party[i].color.g,party[i].color.b,255},2);text(x+120,y,std::to_string(party[i].hp)+"/"+std::to_string(party[i].maxHp),{255,255,255,255},1);}
  text(40,325,"A ATTACK   X CHANGE HERO   B RUN",{100,219,209,255},1); if(messageTicks>0) {panel(165,175,310,30);text(176,185,message,{255,255,255,255},1);} }
 else if(scene==Scene::Party){panel(50,35,540,280);text(75,50,"PARTY STATUS",{100,219,209,255},3);for(int i=0;i<4;i++){int y=105+i*43;text(80,y,party[i].name,{party[i].color.r,party[i].color.g,party[i].color.b,255},2);text(260,y,"HP "+std::to_string(party[i].hp)+" / "+std::to_string(party[i].maxHp),{255,255,255,255},2);rect(420,y,120,10,{50,55,70,255});rect(420,y,120*party[i].hp/party[i].maxHp,10,{100,219,209,255});}text(80,285,"A HEAL TEAM (5 COINS)   B BACK",{255,255,255,255},1);}
 else if(scene==Scene::Options){panel(90,55,460,250);text(145,80,"SYSTEM MENU",{100,219,209,255},3);text(140,145,"A SAVE GAME",{255,255,255,255},2);text(140,185,"B RETURN TO TITLE",{255,255,255,255},2);text(140,225,"ESC BACK TO WORLD",{190,200,225,255},1);}
 SDL_RenderPresent(renderer); }
void handle(SDL_Keycode k){ if(scene==Scene::Title){if(k==SDLK_RETURN||k==SDLK_z||k==SDLK_SPACE){loadGame();scene=Scene::World;}else if(k==SDLK_ESCAPE||k==SDLK_x)running=false;return;}
 if(scene==Scene::World){if(k==SDLK_UP||k==SDLK_w)py-=5;else if(k==SDLK_DOWN||k==SDLK_s)py+=5;else if(k==SDLK_LEFT||k==SDLK_a)px-=5;else if(k==SDLK_RIGHT||k==SDLK_d)px+=5;px=std::clamp(px,12,W-12);py=std::clamp(py,55,H-65);if(k==SDLK_x)scene=Scene::Party;else if(k==SDLK_y||k==SDLK_ESCAPE)scene=Scene::Options;else if(k==SDLK_z||k==SDLK_RETURN){if(px>395&&py<210){startBattle();}else message="NOTHING HERE YET - KEEP EXPLORING";} if((k==SDLK_UP||k==SDLK_DOWN||k==SDLK_LEFT||k==SDLK_RIGHT||k==SDLK_w||k==SDLK_s||k==SDLK_a||k==SDLK_d)&&++encounterSteps%24==0)startBattle();return;}
 if(scene==Scene::Battle){if(k==SDLK_LEFT||k==SDLK_RIGHT||k==SDLK_UP||k==SDLK_DOWN)selected=(selected+1)%4;else if(k==SDLK_x)selected=(selected+1)%4;else if(k==SDLK_z||k==SDLK_RETURN){if(enemy.hp<=0){scene=Scene::World;message="VICTORY!";}else attack();}else if(k==SDLK_x)selected=(selected+1)%4;else if(k==SDLK_ESCAPE||k==SDLK_BACKSPACE){scene=Scene::World;message="YOU RAN AWAY!";}return;}
 if(scene==Scene::Party){if(k==SDLK_z||k==SDLK_RETURN){if(coins>=5){coins-=5;for(auto& h:party)h.hp=h.maxHp;message="TEAM FULLY HEALED!";}else message="NOT ENOUGH COINS";}else if(k==SDLK_x||k==SDLK_ESCAPE)scene=Scene::World;return;}
 if(scene==Scene::Options){if(k==SDLK_z||k==SDLK_RETURN){saveGame();message="GAME SAVED!";}else if(k==SDLK_x){scene=Scene::Title;}else if(k==SDLK_ESCAPE)scene=Scene::World;}
}
}
int main(int argc,char**argv){(void)argc;(void)argv;if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER|SDL_INIT_JOYSTICK)!=0){std::fprintf(stderr,"SDL init failed: %s\n",SDL_GetError());return 1;}window=SDL_CreateWindow("R36S RPG Prototype",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,W,H,SDL_WINDOW_SHOWN);if(!window){std::fprintf(stderr,"Window failed: %s\n",SDL_GetError());SDL_Quit();return 1;}renderer=SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);if(!renderer)renderer=SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE);if(!renderer){SDL_DestroyWindow(window);SDL_Quit();return 1;}SDL_RenderSetLogicalSize(renderer,W,H);for(int i=0;i<SDL_NumJoysticks();i++)SDL_GameControllerOpen(i);Uint32 lastSave=SDL_GetTicks();while(running){SDL_Event e;while(SDL_PollEvent(&e)){if(e.type==SDL_QUIT)running=false;else if(e.type==SDL_KEYDOWN&&e.key.repeat==0)handle(e.key.keysym.sym);else if(e.type==SDL_CONTROLLERBUTTONDOWN){switch(e.cbutton.button){case SDL_CONTROLLER_BUTTON_DPAD_UP:handle(SDLK_UP);break;case SDL_CONTROLLER_BUTTON_DPAD_DOWN:handle(SDLK_DOWN);break;case SDL_CONTROLLER_BUTTON_DPAD_LEFT:handle(SDLK_LEFT);break;case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:handle(SDLK_RIGHT);break;case SDL_CONTROLLER_BUTTON_A:handle(SDLK_z);break;case SDL_CONTROLLER_BUTTON_B:handle(SDLK_x);break;case SDL_CONTROLLER_BUTTON_X:handle(SDLK_y);break;case SDL_CONTROLLER_BUTTON_START:handle(SDLK_ESCAPE);break;}}}if(messageTicks>0)messageTicks--;if(SDL_GetTicks()-lastSave>30000&&scene==Scene::World){saveGame();lastSave=SDL_GetTicks();}render();SDL_Delay(8);}saveGame();SDL_DestroyRenderer(renderer);SDL_DestroyWindow(window);SDL_Quit();return 0;}
