# R36S RPG — prototype source v0.1

This is a from-scratch, playable **technical prototype** for a 2D RPG on Linux handhelds. It is not a complete recreation of FNaF World and does not include proprietary game art/audio. Placeholder graphics are drawn in code.

## Current prototype features
- SDL2 window and 640x360 logical resolution
- Title screen and simple overworld movement
- Random encounter trigger while walking
- Turn-based basic attacks and four placeholder party members
- Party status / heal menu and coin counter
- Local save file (`fnafworld_rpg_save.dat`)
- Keyboard and SDL game-controller input

## Controls
- D-pad / arrow keys: move or change selected hero
- A / Enter / Z: confirm, interact, attack
- B / X: party/back (context-dependent)
- Y: system menu from overworld
- Start / Esc: menu/back

## Build on Linux with SDL2 development files
```sh
sudo apt install g++ make libsdl2-dev pkg-config
make
./fnafworld-r36s
```

## R36S / DarkOS notes
The R36S usually runs an ARM Linux distribution. A binary built on a normal PC will not run on it; it must be cross-compiled for the target architecture and packaged with the correct runtime/library expectations. PortMaster packaging may be possible, but the exact DarkOS base and available SDL2 runtime must be checked first. This ZIP intentionally contains source, not a falsely advertised ready-to-install `.pak`/PortMaster port.

## Next development milestones
1. Verify target ABI and SDL2 libraries on the exact DarkOS image.
2. Add proper controller mapping and test 640x360 scaling.
3. Implement data-driven maps, collisions, dialogue and transitions.
4. Add battle actions, enemy AI, status effects, party switching and progression.
5. Implement robust save slots and settings.
6. Replace placeholder visuals with original or properly licensed assets.

## Copyright
This source is original prototype code and contains no extracted assets from the commercial game. Use only game assets you have the right to use.
